# Creates a class for trucks
class Truck:

    # The constructor for a truck
    def __init__(self, ID, packages, currentAddress, currentTime):
        self.ID = ID
        self.packages = packages
        self.currentAddress = currentAddress
        self.currentTime = currentTime
