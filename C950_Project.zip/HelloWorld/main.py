# Student ID: 011068619
# Author: Andrew Morgan
# Date: 8/19/2023
# Details: This code was written using the
#  "C950 WGUPS Project - Implementation Steps" as a general guideline.


import datetime

from Truck import Truck
from Hash import ChainingHashTable
from CSV import loadPackageData, loadDistanceData, loadAddressData

myHash = ChainingHashTable()
distanceData = []
addressData = []

# Load CSV files into data structures
loadPackageData('WGUPS Package File.csv', myHash)
print('\nPackages Loaded')

loadDistanceData('WGUPS Distance Table.csv', distanceData)
print('Distance Table Loaded')

loadAddressData('addresses.csv', addressData)
print('Addresses Loaded\n')

# Instantiate trucks and load them using package IDs
truck1 = Truck(1, [13, 14, 15, 16, 19, 20, 34, 4, 40, 1, 35, 27, 39, 33, 2, 17], 'HUB', datetime.timedelta(hours=8))
truck2 = Truck(2, [37, 30, 29], 'HUB', datetime.timedelta(hours=8))


# Prints a Package by searching for an ID
def getSinglePackageData(ID):
    print("\nPackage ID: {}".format(myHash.search(ID)))


# Prints all Packages
def getAllPackageData():
    print('================================================================================================================================')
    print('                                                 ALL PACKAGES AT {}'.format(endTime))
    print('================================================================================================================================')
    for i in range(40):
        print("Package ID: {}".format(myHash.search(i + 1)))


# Prints all packages associated with a specific truck
def getAllPackagesByTruck(truckID):
    for i in range(40):
        if (myHash.search(i + 1).status.find(f'truck {truckID}') != -1):
            print("Package ID: {}".format(myHash.search(i + 1)))


# Returns the distance between two addresses
def distanceBetween(address1, address2):
    return distanceData[addressData.index(address1)][addressData.index(address2)]


# Returns the address with the smallest distance between the current address from a list of package IDs within a truck
def minDistanceFrom(fromAddress, truckPackages):
    minDistance = 100
    minPackage = None
    for packageID in truckPackages:
        package = myHash.search(packageID)
        if distanceBetween(fromAddress, package.address) < minDistance:
            minDistance = distanceBetween(fromAddress, package.address)
            minPackage = package
    return [minPackage, minDistance]


# Returns the number of miles a truck has traveled while delivering packages by finding the closest address that
# corresponds to a loaded package in the truck and updates their status up to an inputted time
def truckDeliverPackages(truck):
    truckPackages = truck.packages.copy()
    totalDistance = 0

    while len(truck.packages) > 0:

        returnList = minDistanceFrom(truck.currentAddress, truck.packages)

        if truck.currentTime + datetime.timedelta(hours=returnList[1] / 18) <= endTime:
            totalDistance += returnList[1]
            truck.currentTime += datetime.timedelta(hours=returnList[1] / 18)

            truck.currentAddress = returnList[0].address
            returnList[0].status = 'delivered at {} by truck {}'.format(truck.currentTime, truck.ID)

        truck.packages.remove(returnList[0].ID)

    for packageID in truckPackages:
        if myHash.search(packageID).status.find('delivered') == -1 and truck.currentAddress != 'HUB':
            myHash.search(packageID).status = 'en route on truck {}'.format(truck.ID)

    truck.currentTime += datetime.timedelta(hours=distanceBetween(truck.currentAddress, 'HUB') / 18)
    totalDistance += distanceBetween(truck.currentAddress, 'HUB')
    truck.currentAddress = 'HUB'

    return totalDistance


# Asks the user to input a time. The application then calculates deliveries up to that time, displays the total
# number of miles the trucks have traveled so far, and displays a menu that gives options for viewing packages
if __name__ == '__main__':
    print('What time do you want to go to?')
    print('Enter in the form of HH:MM. Hour Minutes')
    print('Example: 9 AM would be 09:00 and 1 PM would be 13:00')

    inputTime = input('Please enter 08:00 onwards ')
    h, m = inputTime.split(':')
    endTime = datetime.timedelta(hours=int(h), minutes=int(m))

    totalDistance = 0
    # Truck 1 is loaded up at 8:00 and returns at 9:55
    totalDistance += truckDeliverPackages(truck1)

    # Truck 2 is loaded up at 8:00 and returns at 8:55
    totalDistance += truckDeliverPackages(truck2)

    # Truck 2 waits til 9:05, loads up, and returns at 10:02
    truck2.currentTime = datetime.timedelta(hours=9, minutes=5)
    truck2.packages = [6, 25, 28, 32, 26, 31]
    totalDistance += truckDeliverPackages(truck2)

    # Truck 2 waits til 10:20, loads up, and returns at 12:39
    truck2.currentTime = datetime.timedelta(hours=10, minutes=20)
    truck2.packages = [9, 3, 18, 36, 38, 10, 5, 8, 7, 12, 23, 24, 11, 22, 21]
    totalDistance += truckDeliverPackages(truck2)

    print(f'\n\nThe total number of miles traveled by all trucks combined is {totalDistance}\n\n')

    isExit = True
    while (isExit):
        print("\nSelect from the following:")
        print("1 = Look Up Package ID")
        print("2 = Print All Packages")
        print("3 = See All Packages Associated With a Truck")
        print("4 = Exit the Program")
        option = input("Enter Option: ")
        if option == "1":
            ID = int(input("Please enter the Package ID: "))
            getSinglePackageData(ID)
        elif option == "2":
            getAllPackageData()
        elif option == "3":
            truckID = int(input("Please enter the Truck ID: "))
            getAllPackagesByTruck(truckID)
        elif option == "4":
            isExit = False
        else:
            print("Wrong option, please try again!")
