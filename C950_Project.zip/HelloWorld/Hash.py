# This class creates a chaining hash table
class ChainingHashTable:
    # Constructor with optional initial capacity parameter.
    # Assigns all buckets with an empty list.
    def __init__(self, initial_capacity=10):
        self.table = []
        for i in range(initial_capacity):
            self.table.append([])

    # Inserts a new item into the hash table.
    def insert(self, key, item):
        bucket = hash(key) % len(self.table)
        bucketList = self.table[bucket]

        for kv in bucketList:
          if kv[0] == key:
            kv[1] = item
            return True

        keyValue = [key, item]
        bucketList.append(keyValue)
        return True

    # Searches for an item with matching key in the hash table.
    # Returns the item if found, or None if not found.
    def search(self, key):
        bucket = hash(key) % len(self.table)
        bucketList = self.table[bucket]

        for kv in bucketList:
          if kv[0] == key:
            return kv[1]
        return None

    # Removes an item with matching key from the hash table.
    def remove(self, key):
        bucket = hash(key) % len(self.table)
        bucketList = self.table[bucket]

        for kv in bucketList:
          if kv[0] == key:
              bucketList.remove([kv[0],kv[1]])
