package com.example.c195project;

import com.example.c195project.Models.Appointment;
import com.example.c195project.Models.User;
import com.example.c195project.Queries.QueryAppointment;
import com.example.c195project.Queries.QueryUser;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ResourceBundle;

/**This class controls the login scene*/
public class LoginController implements Initializable {

    /**TextField for inputting a username*/
    public TextField usernameField;

    /**TextField for inputting a password*/
    public TextField passwordField;

    /**Label that displays the zoneId*/
    public Label zoneId;

    /**Button for logging into the home screen*/
    public Button loginButton;

    /**Login Scene label*/
    public Label loginLabel;

    public static ZonedDateTime loginTime;

    /**Navigates to home scene if username and password combination exist, provides a dialogue box explaining if there is an upcoming appointment within the next 15 minutes,
     * and writes login activity to a file login_activity.txt*/
    public void onLoginButton(ActionEvent actionEvent) throws IOException, SQLException {
        Alert alert = new Alert(Alert.AlertType.WARNING);

        loginTime = ZonedDateTime.now(ZoneId.of("UTC"));

        Boolean success = false;

        //If username and password are correct navigate to home, else display error
        for(int i = 0; i < QueryUser.getAllUsers().size(); i++) {

           User user = QueryUser.getAllUsers().get(i);

            if(user.getUserName().equals(usernameField.getText()) && user.getPassword().equals(passwordField.getText())) {
                success = true;
            }
        }
        if(success) {

            Parent root = FXMLLoader.load(getClass().getResource("homeScene.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 700, 400));
            stage.show();

            //Provides a dialogue box explaining if there is an upcoming appointment within the next 15 minutes
            Alert alertInfo = new Alert(Alert.AlertType.INFORMATION);
            ObservableList<Appointment> allAppointments;
            try {
                allAppointments = QueryAppointment.getAllAppointments();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            for (int i = 0; i < allAppointments.size(); i++) {

                ZonedDateTime startDateTime = allAppointments.get(i).getStart().toInstant().atZone(ZoneId.of("UTC"));

                if(!(startDateTime.isBefore(loginTime) || startDateTime.isAfter(loginTime.plusMinutes(15)))) {
                    alertInfo.setContentText("There is an upcoming appointment within 15 minutes." + "\nID: " + allAppointments.get(i).getAppointmentId() + ",     DATE: " + allAppointments.get(i).getStart().toLocalDateTime().toLocalDate() + ",     TIME: " + allAppointments.get(i).getStart().toLocalDateTime().toLocalTime());
                    alertInfo.show();
                } else {
                    alertInfo.setContentText("There are no upcoming appointments within the next 15 minutes.");
                    alertInfo.show();
                }
            }

        } else {
            try {
                alert.setTitle(Main.rb.getString("Warning"));
                alert.setHeaderText(Main.rb.getString("Warning"));
                alert.setContentText(Main.rb.getString("errorMessage"));
            } catch (NullPointerException e) {
                alert.setContentText("The username or password is incorrect!");
            }
                alert.show();
       }

        //Writes login activity to a file login_activity.txt
        try {
            File f1 = new File("login_activity.txt");
            if(!f1.exists()) {
                f1.createNewFile();
            }

            FileWriter fileWriter = new FileWriter(f1.getName(),true);
            BufferedWriter bw = new BufferedWriter(fileWriter);
            bw.write("Timestamp: " + loginTime.toLocalDateTime() + " UTC    Username attempt: " + usernameField.getText() + "    Successful: " + success + "\n\n");
            bw.close();

        } catch(IOException e){
            e.printStackTrace();
        }
    }

    /**Implements onLoginButton when ENTER is pressed on the Username Field*/
    public void onUsername(ActionEvent actionEvent) throws IOException, SQLException {
        onLoginButton(actionEvent);
    }

    /**Implements onLoginButton when ENTER is pressed on the Password Field*/
    public void onPassword(ActionEvent actionEvent) throws IOException, SQLException {
        onLoginButton(actionEvent);
    }

    /**Translates all the text to French if the system's default language is French, otherwise it remains in english*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            zoneId.setText(Main.rb.getString("Location") + ": " + ZoneId.systemDefault());
            loginLabel.setText(Main.rb.getString("Login"));
            passwordField.setPromptText(Main.rb.getString("Password"));
            usernameField.setPromptText(Main.rb.getString("Username"));
            loginButton.setText(Main.rb.getString("Submit"));
        } catch (NullPointerException e) {
            zoneId.setText("Location: " + ZoneId.systemDefault());
            System.out.println("System not in French. Set to application default");
        }
    }

}
