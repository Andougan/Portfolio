package com.example.c195project;

import com.example.c195project.Models.Country;
import com.example.c195project.Models.Customer;
import com.example.c195project.Queries.QueryCountry;
import com.example.c195project.Queries.QueryCustomer;
import com.example.c195project.Queries.QueryDivision;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

/**This class controls the update customer scene*/
public class CustomerUpdateController {

    /**Field for the Customer ID of a customer*/
    public TextField idField;

    /**Field for the Name of a customer*/
    public TextField nameField;

    /**Field for the Address of a customer*/
    public TextField addressField;

    /**Field for the Postal Code of a customer*/
    public TextField postalField;

    /**Field for the Phone Number of a customer*/
    public TextField phoneField;

    /**Combo Box for choosing the First Level Division of a customer*/
    public ComboBox divisionBox;

    /**Combo Box for choosing the Country of a customer*/
    public ComboBox countryBox;


    private static int customerIndex;
    /**When a country from the country combo box is selected, the division combo box only displays items associated with the that country*/
    public void onCountry(ActionEvent actionEvent) throws SQLException {

        divisionBox.getSelectionModel().select(null);
        divisionBox.getItems().clear();

        divisionBox.setItems(QueryDivision.getDivisionsByCountryId(QueryCountry.selectCountryId(countryBox.getValue().toString())));

        System.out.println("Items returned in division comboBox: " + divisionBox.getItems().size());
    }

    /**Updates a customer from the database using data from all the fields and boxes if none of them are empty*/
    public void onSaveButton(ActionEvent actionEvent) throws IOException, SQLException {

        Alert alert = new Alert(Alert.AlertType.WARNING);

        if (!nameField.getText().isEmpty() && !addressField.getText().isEmpty() && !postalField.getText().isEmpty() && !phoneField.getText().isEmpty() && divisionBox.getSelectionModel().getSelectedItem() != null) {

            QueryCustomer.updateCustomer( customerIndex, nameField.getText(), addressField.getText(), postalField.getText(), phoneField.getText(), QueryDivision.selectDivisionId((String) divisionBox.getSelectionModel().getSelectedItem()));

            Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 700, 400));
            stage.show();

        } else {
            alert.setContentText("Fields cannot be empty!");
            alert.show();

        }
    }

    /**Navigates to the customer view scene without saving*/
    public void onCancelButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();

    }

    /**Populates the fields and selects items from boxes using data from the customer selected in the customer table.
     * This method also sets the items to be selected from the country and division combo boxes*/
    public void setCustomerData(Customer selectedCustomer) throws SQLException {

        for(Country c : QueryCountry.getAllCountries()) {
            countryBox.getItems().add(c.getCountryName());
        }

        customerIndex = selectedCustomer.getCustomerId();

        idField.setPromptText(String.valueOf(selectedCustomer.getCustomerId()));
        nameField.setText(selectedCustomer.getCustomerName());
        addressField.setText(selectedCustomer.getAddress());
        postalField.setText(selectedCustomer.getPostalCode());
        phoneField.setText(selectedCustomer.getPhone());

        countryBox.getSelectionModel().select(selectedCustomer.getCountry());
        divisionBox.getSelectionModel().select(selectedCustomer.getDivision());


        divisionBox.setItems(QueryDivision.getDivisionsByCountryId(QueryCountry.selectCountryId(countryBox.getValue().toString())));
    }

}
