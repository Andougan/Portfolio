package com.example.c195project;

import com.example.c195project.Models.CustomerTotalPerCountry;
import com.example.c195project.Queries.QueryCustomer;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**This class controls the customer residency report scene*/
public class CustomerResidencyReportController implements Initializable {

    /**The Customer Total Per Country table view*/
    public TableView<CustomerTotalPerCountry> myTable;

    /**Country column*/
    public TableColumn countryCol;

    /**Number of customers per country column*/
    public TableColumn countCol;

    /**Navigates to the home scene*/
    public void onHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homeScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the Customer view scene*/
    public void onCustomers(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the Appointment view scene*/
    public void onAppointments(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1030, 400));
        stage.show();
    }

    /**Populates the table and prepares its columns for population*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            myTable.setItems(QueryCustomer.selectGroupByCountry());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        countryCol.setCellValueFactory(new PropertyValueFactory<>("country"));
        countCol.setCellValueFactory(new PropertyValueFactory<>("count"));
    }
}
