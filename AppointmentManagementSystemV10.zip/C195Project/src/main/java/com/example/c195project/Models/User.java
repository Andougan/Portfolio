package com.example.c195project.Models;

/**This class defines an object class for users*/
public class User {

    /**The User ID of a user*/
    private int userId;

    /**The Username of a user*/
    private String userName;

    /**The Password of a user*/
    private String password;

    /**User constructor*/
    public User(int userId, String userName, String password) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
    }

    /**Returns user id*/
    public int getUserId() {
        return userId;
    }

    /**Returns username*/
    public String getUserName() {
        return userName;
    }

    /**Returns password*/
    public String getPassword() {
        return password;
    }




    /**Sets user id*/
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**Sets username*/
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**Sets password*/
    public void setPassword(String password) {
        this.password = password;
    }
}
