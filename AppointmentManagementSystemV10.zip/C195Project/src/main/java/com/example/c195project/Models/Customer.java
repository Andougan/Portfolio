package com.example.c195project.Models;

/**This class defines an object class for customers*/
public class Customer {

    /**The Customer ID of a Customer*/
    private int customerId;

    /**The Name of a customer*/
    private String customerName;

    /**The Address of a customer*/
    private String address;

    /**The Postal Code of a customer*/
    private String postalCode;

    /**The Phone Number of a customer*/
    private String phone;

    /**The Country of a customer*/
    private String country;

    /**The first level division of a customer*/
    private String division;

    /**Customer constructor*/
    public Customer(int customerId, String customerName, String address, String postalCode, String phone, String country, String division) {

        this.customerId = customerId;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.country = country;
        this.division = division;

    }

    /**Returns customer id*/
    public int getCustomerId() {
        return customerId;
    }

    /**Returns customer name*/
    public String getCustomerName() {
        return customerName;
    }

    /**Returns address*/
    public String getAddress() {
        return address;
    }

    /**Returns postal code*/
    public String getPostalCode() {
        return postalCode;
    }

    /**Returns phone*/
    public String getPhone() {
        return phone;
    }

    /**Returns country*/
    public String getCountry() {
        return country;
    }

    /**Returns first level division*/
    public String getDivision() {
        return division;
    }




    /**Returns customer id*/
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**Returns customer name*/
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**Returns address*/
    public void setAddress(String address) {
        this.address = address;
    }

    /**Returns postal code*/
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**Returns phone*/
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**Returns country*/
    public void setCountry(String country) {
        this.country = country;
    }

    /**Returns first level division*/
    public void setDivision(String division) {
        this.division = division;
    }

}
