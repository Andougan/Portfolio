package com.example.c195project.Queries;

import com.example.c195project.JDBC;
import com.example.c195project.Models.Contact;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This class contains methods that query the contacts table from the client_schedule database*/
public class QueryContact {

    private static ObservableList<Contact> allContacts = FXCollections.observableArrayList();

    /**Selects a contact name with a specific contact id*/
    public static String selectContactName(int contactId) throws SQLException {
        String sql = "SELECT * FROM contacts WHERE Contact_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, contactId);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            return rs.getString("Contact_Name");
        }

        return null;
    }

    /**Selects a contact id with a specific contact name*/
    public static int selectContactId(String contactName) throws SQLException {
        String sql = "SELECT * FROM contacts WHERE Contact_name = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, contactName);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            return rs.getInt("Contact_ID");
        }
        return 0;
    }

    /**Adds all the contacts from the database to an observable list*/
    public static void selectAllContacts() throws SQLException {
        if(allContacts.size() < 1) {
            String sql = "SELECT * FROM contacts";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Contact contact = new Contact(rs.getInt("Contact_ID"), rs.getString("Contact_Name"), rs.getString("Email"));
                allContacts.add(contact);
            }
        }
    }

    /**Returns an observable list of all contacts from the database*/
    public static ObservableList<Contact> getAllContacts() throws SQLException {
        selectAllContacts();
        return allContacts;
    }
}
