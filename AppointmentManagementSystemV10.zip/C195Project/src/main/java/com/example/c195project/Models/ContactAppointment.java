package com.example.c195project.Models;

import java.sql.Timestamp;

/**This class defines the object class for Contact Appointments*/
public class ContactAppointment {

    /**The Appointment ID of an appointment*/
    private int appointmentId;

    /**The Title of an appointment*/
    private String title;

    /**The Description of an appointment*/
    private String description;

    /**The Type of appointment*/
    private String type;

    /**The Start date and time of an appointment*/
    private Timestamp start;

    /**The End date and time of an appointment*/
    private Timestamp end;

    /**The Customer ID associated with an appointment*/
    private int customerId;



    /**contactAppointment constructor*/
    public ContactAppointment(int appointmentId, String title, String description, String type, Timestamp start, Timestamp end, int customerId) {
        this.appointmentId = appointmentId;
        this.title = title;
        this.description = description;
        this.type = type;
        this.start = start;
        this.end = end;
        this.customerId = customerId;
    }

    /**Returns appointment id*/
    public int getAppointmentId() {
        return appointmentId;
    }

    /**Returns title*/
    public String getTitle() {
        return title;
    }

    /**Returns description*/
    public String getDescription() {
        return description;
    }

    /**Returns type*/
    public String getType() {
        return type;
    }

    /**Returns start timestamp*/
    public Timestamp getStart() {
        return start;
    }

    /**Returns end timestamp*/
    public Timestamp getEnd() {
        return end;
    }

    /**Returns customer id*/
    public int getCustomerId() {
        return customerId;
    }




    /**Sets appointment id*/
    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    /**Sets title*/
    public void setTitle(String title) {
        this.title = title;
    }

    /**Sets description*/
    public void setDescription(String description) {
        this.description = description;
    }

    /**Sets type*/
    public void setType(String type) {
        this.type = type;
    }

    /**Sets start timestamp*/
    public void setStart(Timestamp start) {
        this.start = start;
    }

    /**Sets end timestamp*/
    public void setEnd(Timestamp end) {
        this.end = end;
    }

    /**Sets customer id*/
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

}