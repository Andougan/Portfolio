package com.example.c195project.Queries;

import com.example.c195project.JDBC;
import com.example.c195project.Models.Division;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This class contains methods that query the first_level_divisions table from the client_schedule database*/
public class QueryDivision {

    private static ObservableList<Division> allDivisions = FXCollections.observableArrayList();

    /**Selects a country id with a specific division id*/
    public static int selectCountryId(int divisionId) throws SQLException {

        String sql = "SELECT * FROM first_level_divisions WHERE Division_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, divisionId);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            return rs.getInt("Country_ID");
        }
        return 0;
    }

    /**Selects a division name with specific division id*/
    public static String selectDivisionName(int divisionId) throws SQLException {
        String sql = "SELECT * FROM first_level_divisions WHERE Division_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, divisionId);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            return rs.getString("Division");
        }
        return null;
    }

    /**Selects a division id with a specific division name*/
    public static int selectDivisionId(String divisionName) throws SQLException {
        String sql = "SELECT * FROM first_level_divisions WHERE Division = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, divisionName);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            return rs.getInt("Division_ID");
        }
        return 0;
    }

    /**Returns an observable list of divisions with the same country id*/
    public static ObservableList<String> getDivisionsByCountryId(int countryId) throws SQLException {

        ObservableList<String> divisions = FXCollections.observableArrayList();

        String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = ?";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, countryId);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            divisions.add(rs.getString("Division"));
        }

        return divisions;
    }

    /**Adds all the divisions from the database to an observable list*/
    public static void selectAllDivisions() throws SQLException {

        allDivisions.clear();

        String sql = "SELECT * FROM first_level_divisions";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            allDivisions.add(new Division(rs.getInt("Division_ID"), rs.getString("Division"),
                    rs.getInt("Country_ID")));
        }

    }

    /**Returns an observable list of all divisions from the database*/
    public static ObservableList<Division> getAllDivisions() {
        return allDivisions;
    }

}
