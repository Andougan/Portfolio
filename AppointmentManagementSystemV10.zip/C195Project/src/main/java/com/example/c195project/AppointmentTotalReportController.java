package com.example.c195project;

import com.example.c195project.Models.AppointmentTotal;
import com.example.c195project.Queries.QueryAppointment;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**This class controls the appointment report scene*/
public class AppointmentTotalReportController implements Initializable {

    /**The Appointment Report table view*/
    public TableView<AppointmentTotal> appointmentReportTable;

    /**Month column*/
    public TableColumn monthCol;

    /**Type column*/
    public TableColumn typeCol;

    /**Number of appointments per combination of type and month column*/
    public TableColumn countCol;

    /**Navigates to the home scene*/
    public void onHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homeScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the customer view scene*/
    public void onCustomers(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the appointment view scene*/
    public void onAppointments(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1030, 400));
        stage.show();
    }

    /**Populates the customer table and prepares its columns for population*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        try {
            appointmentReportTable.setItems(QueryAppointment.selectGroupByTypeMonthCount());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        countCol.setCellValueFactory(new PropertyValueFactory<>("count"));
    }
}
