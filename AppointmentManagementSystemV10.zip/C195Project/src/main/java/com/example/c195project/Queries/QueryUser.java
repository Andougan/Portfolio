package com.example.c195project.Queries;

import com.example.c195project.JDBC;
import com.example.c195project.Models.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This class contains methods that query the users table from the client_schedule database*/
public class QueryUser {
    private static ObservableList<User> allUsers = FXCollections.observableArrayList();

    /**Adds all the users from the database to an observable list*/
    public static void selectAllUsers() throws SQLException {
        if(allUsers.size() < 1) {
            String sql = "SELECT * FROM users";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User(rs.getInt("User_ID"), rs.getString("User_Name"), rs.getString("Password"));
                allUsers.add(user);
            }
        }
    }

    /**Returns an observable list of all users from the database*/
    public static ObservableList<User> getAllUsers() throws SQLException {
        selectAllUsers();
        return allUsers;
    }

}
