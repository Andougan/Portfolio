package com.example.c195project;

import com.example.c195project.Models.Country;
import com.example.c195project.Queries.QueryCountry;
import com.example.c195project.Queries.QueryCustomer;
import com.example.c195project.Queries.QueryDivision;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**This class controls the add customer scene*/
public class CustomerAddController implements Initializable {

    /**Field for the Customer ID of a customer*/
    public TextField idField;

    /**Field for the Name of a customer*/
    public TextField nameField;

    /**Field for the Address of a customer*/
    public TextField addressField;

    /**Field for the Postal Code of a customer*/
    public TextField postalField;

    /**Field for the Phone Number of a customer*/
    public TextField phoneField;

    /**Combo Box for choosing the First Level Division of a customer*/
    public ComboBox divisionBox;

    /**Combo Box for choosing the Country of a customer*/
    public ComboBox countryBox;


    /**When a country from the country combo box is selected, the division combo box only displays items associated with that country*/
    public void onCountryBox(ActionEvent actionEvent) throws SQLException {

        divisionBox.getSelectionModel().select(null);
        divisionBox.getItems().clear();

        divisionBox.setItems(QueryDivision.getDivisionsByCountryId(QueryCountry.selectCountryId(countryBox.getValue().toString())));

        System.out.println("Items returned in division comboBox: " + divisionBox.getItems().size());

    }

    /**Inserts a new customer into the database using data from all the fields and boxes if none of them are empty*/
    public void onSaveButton(ActionEvent actionEvent) throws IOException, SQLException {

        if(!nameField.getText().isEmpty() && !addressField.getText().isEmpty() && !postalField.getText().isEmpty() && !phoneField.getText().isEmpty() && divisionBox.getValue() != null) {

            QueryCustomer.insertCustomer(nameField.getText(), addressField.getText(), postalField.getText(), phoneField.getText(), QueryDivision.selectDivisionId(divisionBox.getValue().toString()));

            Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 700, 400));
            stage.show();

        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Fields cannot be empty!");
            alert.show();
        }

    }

    /**Navigates to the customer view scene without saving*/
    public void onCancelButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();

    }

    /**Sets the countries to be selected from the country combo box*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            for(Country c : QueryCountry.getAllCountries()) {
                countryBox.getItems().add(c.getCountryName());
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

}
