package com.example.c195project;

import com.example.c195project.Models.Customer;
import com.example.c195project.Queries.QueryAppointment;
import com.example.c195project.Queries.QueryCustomer;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Optional;
import java.util.ResourceBundle;

/**This class controls the customer view scene*/
public class CustomerViewController implements Initializable {

    /**The Customers table view*/
    public TableView<Customer> customersTable;

    /**Customer ID column*/
    public TableColumn customerIdCol;

    /**Name column*/
    public TableColumn customerNameCol;

    /**Address column*/
    public TableColumn customerAddressCol;

    /**Postal Code column*/
    public TableColumn customerPostalCol;

    /**Phone Number column*/
    public TableColumn customerPhoneCol;

    /**First Level Division column*/
    public TableColumn customerDivisionCol;

    /**Country column*/
    public TableColumn customerCountryCol;

    /**Navigates to the home scene*/
    public void onHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homeScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the Customer view scene*/
    public void onCustomers(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the Appointment view scene*/
    public void onAppointments(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1030, 400));
        stage.show();
    }

    Alert alert = new Alert(Alert.AlertType.WARNING);

    /**Navigates to the add customer scene*/
    public void onAddCustomer(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("addCustomerScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 500, 550));
        stage.show();
    }

    /**Deletes the customer selected in the customer table and all appointments with the same customer ID as the selected customer from the database*/
    public void onDeleteCustomer(ActionEvent actionEvent) throws SQLException {

        if (!customersTable.getSelectionModel().isEmpty()) {
            Customer customer = customersTable.getSelectionModel().getSelectedItem();

            Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION, "The selected customer and all appointments with Customer ID equal to " + customer.getCustomerId() + " will be deleted! Are you sure you want to delete this customer?");
            Alert alertInfo = new Alert(Alert.AlertType.INFORMATION, "The selected customer and all appointments with Customer ID equal to " + customer.getCustomerId() + " have been deleted.");

            Optional<ButtonType> result = confirmAlert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                    QueryAppointment.deleteAppointmentByCustomerId(customer.getCustomerId());

                    QueryCustomer.deleteCustomer(customer.getCustomerId());
                    QueryCustomer.getAllCustomers().remove(customer);

                    customersTable.setItems(QueryCustomer.getAllCustomers());

                    alertInfo.show();

            }
        } else {
            alert.setContentText("Could not delete. Customer not selected!");
            alert.show();
        }

    }

    /**Passes the selected customer data to the update customer scene and then navigates to it*/
    public void onUpdateCustomer(ActionEvent actionEvent) throws IOException, SQLException {

        try {
            FXMLLoader loader = new FXMLLoader();

            loader.setLocation(getClass().getResource("updateCustomerScene.fxml"));
            Parent parent = loader.load();

            CustomerUpdateController updateCustomerController = loader.getController();
            updateCustomerController.setCustomerData(customersTable.getSelectionModel().getSelectedItem());

            Scene scene = new Scene(parent, 500, 550);

            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

        } catch (NullPointerException e) {
            alert.setContentText("Could not update. Customer not selected!");
            alert.showAndWait();
        }
    }

    /**Populates the customer table and prepares its columns for population*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        try {
            customersTable.setItems(QueryCustomer.getAllCustomers());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerAddressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        customerPhoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        customerPostalCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        customerCountryCol.setCellValueFactory(new PropertyValueFactory<>("country"));
        customerDivisionCol.setCellValueFactory(new PropertyValueFactory<>("division"));
    }
}
