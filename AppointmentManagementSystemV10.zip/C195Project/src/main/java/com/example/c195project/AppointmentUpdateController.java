package com.example.c195project;

import com.example.c195project.Models.Appointment;
import com.example.c195project.Models.Contact;
import com.example.c195project.Models.Customer;
import com.example.c195project.Models.User;
import com.example.c195project.Queries.QueryAppointment;
import com.example.c195project.Queries.QueryContact;
import com.example.c195project.Queries.QueryCustomer;
import com.example.c195project.Queries.QueryUser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;

/**This class controls the update appointment scene*/
public class AppointmentUpdateController {

    /**Auto generated field for the Appointment ID*/
    public TextField idField;

    /**Field for the Title of an appointment*/
    public TextField titleField;

    /**Field for the Description of an appointment*/
    public TextField descriptionField;

    /**Field for the Location of an appointment*/
    public TextField locationField;

    /**Combo Box for choosing the Contact of an appointment*/
    public ComboBox contactBox;

    /**Field for the Type of appointment*/
    public TextField typeField;

    /**Date Picker for choosing the Start date of an appointment*/
    public DatePicker startDatePicker;

    /**Combo Box for choosing the Start time of an appointment*/
    public ComboBox startTimeBox;

    /**Date Picker for choosing the End date of an appointment*/
    public DatePicker endDatePicker;

    /**Field for choosing the End time of an appointment*/
    public ComboBox endTimeBox;

    /**Combo Box for choosing the associated Customer ID of an appointment*/
    public ComboBox customerIdBox;

    /**Combo Box for choosing the associated User ID of an appointment*/
    public ComboBox userIdBox;


    private static int appointmentId;
    Alert alert = new Alert(Alert.AlertType.WARNING);

    /**Updates a new appointment into the database using data from all the fields and boxes as long as none of them are empty
     * and the appointment time does not overlap another appointment of the same customer id*/
    public void onSaveButton(ActionEvent actionEvent) throws IOException, SQLException {

        if(!titleField.getText().isEmpty() && !descriptionField.getText().isEmpty() && !locationField.getText().isEmpty() &&
                !typeField.getText().isEmpty() && contactBox.getValue() != null && customerIdBox.getValue() != null &&
                userIdBox.getValue() != null && startTimeBox.getValue() != null && endTimeBox.getValue() != null &&
                startDatePicker.getValue() != null && endDatePicker.getValue() != null) {

            LocalDateTime startDateTime= Timestamp.valueOf(startDatePicker.getValue().atTime((LocalTime) startTimeBox.getValue())).toLocalDateTime();
            LocalDateTime endDateTime = Timestamp.valueOf(endDatePicker.getValue().atTime((LocalTime) endTimeBox.getValue())).toLocalDateTime();

            ObservableList<Appointment> allAppointments = QueryAppointment.getAllAppointments();
            ObservableList<Appointment> allCustomerAppointments = FXCollections.observableArrayList();

            Boolean isOverlapping = false;

            if (startDateTime.isBefore(endDateTime)) {

                for (int i = 0; i < allAppointments.size(); i++) {
                    if (allAppointments.get(i).getCustomerId() == (int) customerIdBox.getValue() && allAppointments.get(i).getAppointmentId() != Integer.valueOf(idField.getText())) {
                        allCustomerAppointments.add(allAppointments.get(i));
                    }
                }

                for (int i = 0; i < allCustomerAppointments.size(); i++) {

                    LocalDateTime customerStartTime = allCustomerAppointments.get(i).getStart().toLocalDateTime();
                    LocalDateTime customerEndTime = allCustomerAppointments.get(i).getEnd().toLocalDateTime();

                    if(startDateTime.isAfter(customerStartTime) && startDateTime.isBefore(customerEndTime)) {
                        isOverlapping = true;
                        System.out.println("Start During");
                    }
                    else if(startDateTime.isBefore(customerStartTime) && endDateTime.isAfter(customerStartTime)) {
                        isOverlapping = true;
                        System.out.println("Engulfing");
                    } else if (startDateTime.isAfter(customerStartTime) && endDateTime.isBefore(customerEndTime)) {
                        isOverlapping = true;
                        System.out.println("Inner");
                    } else if(startDateTime.isEqual(customerStartTime) || endDateTime.isEqual(customerEndTime)) {
                        isOverlapping = true;
                        System.out.println("Exact");
                    }
                }

                if (!isOverlapping) {
                    QueryAppointment.updateAppointment(appointmentId, titleField.getText(), descriptionField.getText(), locationField.getText(), typeField.getText(),
                            Timestamp.valueOf(startDatePicker.getValue().atTime((LocalTime) startTimeBox.getValue())),
                            Timestamp.valueOf(endDatePicker.getValue().atTime((LocalTime) endTimeBox.getValue())),
                            (int) customerIdBox.getValue(), (int) userIdBox.getValue(), QueryContact.selectContactId(contactBox.getValue().toString()));

                    Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    stage.setScene(new Scene(root, 1030, 400));
                    stage.show();

                }  else {
                    alert.setContentText("Appointments cannot be scheduled for the same time as another appointment with the same customer!");
                    alert.show();
                }

            }  else {
                alert.setContentText("Appointment start time needs to be before end time!");
                alert.show();
            }

        } else {
            alert.setContentText("Fields cannot be empty!");
            alert.show();
        }
    }

    /**Navigates to the appointment view scene without saving*/
    public void onCancelButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1030, 400));
        stage.show();
    }

    /**Populates the fields and selects items from boxes using data from the customer selected in the customer table.
     * This method also sets the items to be selected from the start time, end time, contact, customer id, and user id combo boxes*/
    public void setAppointmentData(Appointment selectedAppointment) {

        ZonedDateTime easternStart = ZonedDateTime.of(LocalDate.now(), LocalTime.of(8, 0), ZoneId.of("America/New_York"));
        LocalTime localStart = easternStart.withZoneSameInstant(ZoneId.systemDefault()).toLocalTime();
        LocalTime localEnd = localStart.plusHours(14);

        while(localStart.isBefore(localEnd)) {
            startTimeBox.getItems().add(localStart);
            localStart = localStart.plusMinutes(15);
            endTimeBox.getItems().add(localStart);
        }

        try {
            for (Contact c : QueryContact.getAllContacts()) {
                contactBox.getItems().add(c.getContactName());
            }
            for (Customer c : QueryCustomer.getAllCustomers()) {
                customerIdBox.getItems().add(c.getCustomerId());
            }
            for (User u : QueryUser.getAllUsers()) {
                userIdBox.getItems().add(u.getUserId());
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        appointmentId = selectedAppointment.getAppointmentId();

        idField.setText(String.valueOf(selectedAppointment.getAppointmentId()));
        titleField.setText(selectedAppointment.getTitle());
        descriptionField.setText(selectedAppointment.getDescription());
        locationField.setText(selectedAppointment.getLocation());
        typeField.setText(selectedAppointment.getType());

        contactBox.setValue(selectedAppointment.getContact());
        customerIdBox.setValue(selectedAppointment.getCustomerId());
        userIdBox.setValue(selectedAppointment.getUserId());

        startTimeBox.setValue(selectedAppointment.getStart().toLocalDateTime().toLocalTime());
        endTimeBox.setValue(selectedAppointment.getEnd().toLocalDateTime().toLocalTime());

        startDatePicker.setValue(selectedAppointment.getStart().toLocalDateTime().toLocalDate());
        endDatePicker.setValue(selectedAppointment.getEnd().toLocalDateTime().toLocalDate());
    }
}
