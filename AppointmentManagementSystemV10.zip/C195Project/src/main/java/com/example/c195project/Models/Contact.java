package com.example.c195project.Models;

/**This class defines an object class for contacts*/
public class Contact {

    /**The Contact ID of a contact*/
    private int contactId;

    /**The Name of a contact*/
    private String contactName;

    /**The Email of a contact*/
    private String email;

    /**Contact constructor*/
    public Contact(int contactId, String contactName, String email) {
        this.contactId = contactId;
        this.contactName = contactName;
        this.email = email;
    }

    /**Returns contact id*/
    public int getContactId() {
        return contactId;
    }

    /**Returns contact name*/
    public String getContactName() {
        return contactName;
    }

    /**Returns contact email*/
    public String getEmail() {
        return email;
    }


    /**Sets contact id*/
    public void setContactId(int contactId) {
        this.contactId = contactId;
    }

    /**Sets contact name*/
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    /**Sets contact email*/
    public void setEmail(String email) {
        this.email = email;
    }
}
