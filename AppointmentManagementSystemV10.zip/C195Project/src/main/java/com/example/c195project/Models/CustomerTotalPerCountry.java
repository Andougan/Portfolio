package com.example.c195project.Models;

/**This class defines an object class for the total customers in a country*/
public class CustomerTotalPerCountry {

    /**The Country of several customers*/
    private String country;

    /**The Total number of customers that live in a particular country*/
    private int count;

    /**CustomerTotalPerCountry constructor*/
    public CustomerTotalPerCountry(String country, int count) {
        this.country = country;
        this.count = count;
    }

    /**Returns country*/
    public String getCountry() {
        return country;
    }


    /**Returns count*/
    public int getCount() {
        return count;
    }




    /**Sets country*/
    public void setCountry(String country) {
        this.country = country;
    }

    /**Sets count*/
    public void setCount(int count) {
        this.count = count;
    }

}
