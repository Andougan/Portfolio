package com.example.c195project.Queries;

import com.example.c195project.JDBC;
import com.example.c195project.Models.Country;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This class contains methods that query the countries table from the client_schedule database*/
public class QueryCountry {

    private static ObservableList<Country> allCountries = FXCollections.observableArrayList();

    /**Selects a country name with a specific country id*/
    public static String selectCountryName(int countryId) throws SQLException {

        String sql = "SELECT * FROM countries WHERE Country_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, countryId);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            return rs.getString("Country");
        }
        return null;
    }

    /**Selects a country id with a specific country name*/
    public static int selectCountryId(String countryName) throws SQLException {
        String sql = "SELECT * FROM countries WHERE Country = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, countryName);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {
            return rs.getInt("Country_ID");
        }
        return 0;
    }

    /**Adds all the countries from the database to an observable list*/
    public static void selectAllCountries() throws SQLException {
        if(allCountries.size() < 1) {
            String sql = "SELECT * FROM countries";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                allCountries.add(new Country(rs.getInt("Country_ID"), rs.getString("Country")));
            }
        }
    }

    /**Returns an observable list of all countries from the database*/
    public static ObservableList<Country> getAllCountries() throws SQLException {
        selectAllCountries();
        return allCountries;
    }

}
