package com.example.c195project.Queries;

import com.example.c195project.JDBC;
import com.example.c195project.Models.Customer;
import com.example.c195project.Models.CustomerTotalPerCountry;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This class contains methods that query the countries table from the client_schedule database*/
public class QueryCustomer {

    private static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

    /**Inserts a new customer into the database*/
    public static void insertCustomer(String customerName, String address, String postalCode, String phone, int divisionId) throws SQLException {
        String sql = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) VALUES (?, ?, ?, ?, NOW(), 'Script', NOW(), 'Script', ?)";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, customerName);
        ps.setString(2,address);
        ps.setString(3, postalCode);
        ps.setString(4, phone);
        ps.setInt(5, divisionId);

        System.out.println("Rows inserted: " + ps.executeUpdate());
    }

    /**Deletes a customer with a specific customer id*/
    public static void deleteCustomer(int customerId) throws SQLException {

        String sql = "DELETE FROM customers WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, customerId);

        System.out.println("Rows deleted: " + ps.executeUpdate());
    }

    /**Updates a customer at a specific customer id*/
    public static void updateCustomer(int customerId ,String customerName, String address, String postalCode, String phone, int divisionId) throws SQLException {
        String sql = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Division_ID = ? WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, customerName);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phone);
        ps.setInt(5, divisionId);
        ps.setInt(6, customerId);

        System.out.println("Rows updated: " + ps.executeUpdate());
    }

    /**Returns an observable list of customer totals per country*/
    public static ObservableList<CustomerTotalPerCountry> selectGroupByCountry() throws SQLException {

        ObservableList<CustomerTotalPerCountry> allItems = FXCollections.observableArrayList();

        String sql = "SELECT Country, COUNT(Customer_ID) FROM customers " +
                "LEFT JOIN first_level_divisions ON customers.Division_ID = first_level_divisions.Division_ID " +
                "LEFT JOIN countries ON first_level_divisions.Country_ID = countries.Country_ID GROUP BY Country";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            CustomerTotalPerCountry item = new CustomerTotalPerCountry(rs.getString("Country"), rs.getInt("COUNT(Customer_ID)"));
            allItems.add(item);
        }

        return allItems;
    }


    /**Adds all the customers from the database to an observable list*/
    public static void selectAllCustomers() throws SQLException {

        allCustomers.clear();

        String sql = "SELECT * FROM customers";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Customer customer = new Customer(rs.getInt("Customer_ID"), rs.getString("Customer_Name"),
                    rs.getString("Address"), rs.getString("Postal_Code"), rs.getString("Phone"),
                    QueryCountry.selectCountryName(QueryDivision.selectCountryId(rs.getInt("Division_ID"))),
                    QueryDivision.selectDivisionName(rs.getInt("Division_ID")));

            allCustomers.add(customer);
        }
    };

    /**Returns an observable list of all customers from the database*/
    public static ObservableList<Customer> getAllCustomers() throws SQLException {
        selectAllCustomers();
        return allCustomers;
    }

}
