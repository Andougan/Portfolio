package com.example.c195project;

import com.example.c195project.Models.Appointment;
import com.example.c195project.Models.Contact;
import com.example.c195project.Models.ContactAppointment;
import com.example.c195project.Queries.QueryAppointment;
import com.example.c195project.Queries.QueryContact;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**This class controls the contact schedule report scene*/
public class ContactScheduleController implements Initializable {

    /**The Contact Schedule table view*/
    public TableView<ContactAppointment> scheduleTable;

    /**Appointment ID column*/
    public TableColumn appointmentIdCol;

    /**Title column*/
    public TableColumn appointmentTitleCol;

    /**Description column*/
    public TableColumn appointmentDescriptionCol;

    /**Type column*/
    public TableColumn appointmentTypeCol;

    /**Start date and time column*/
    public TableColumn appointmentStartCol;

    /**End date and time column*/
    public TableColumn appointmentEndCol;

    /**Customer ID column*/
    public TableColumn appointmentCustomerIdCol;

    /**Combo Box for choosing a contact*/
    public ComboBox contactBox;



    /**Navigates to the home scene*/
    public void onHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homeScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the Customer view scene*/
    public void onCustomers(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the Appointment view scene*/
    public void onAppointments(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1030, 400));
        stage.show();
    }

    /**Populates the table by displaying all appointments associated with the contact selected from the contact combo box*/
    public void onContactBox(ActionEvent actionEvent) throws SQLException {

        scheduleTable.setItems(QueryAppointment.selectAppointmentsByContactID(QueryContact.selectContactId(contactBox.getValue().toString())));

    }

    /**Sets the items to be selected from the contact combo box and prepares the table columns for population*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            for (Contact c : QueryContact.getAllContacts()) {
                contactBox.getItems().add(c.getContactName());
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        appointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        appointmentStartCol.setCellValueFactory(new PropertyValueFactory<>("start"));
        appointmentEndCol.setCellValueFactory(new PropertyValueFactory<>("end"));
        appointmentCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));

    }

}
