package com.example.c195project.Models;

/**This class defines an object for first level divisions*/
public class Division {

    /**The Country ID associated with a division*/
    private int countryId;

    /**The Name of a division*/
    private String division;

    /**The Division ID of a division*/
    private int divisionId;

    /**First level division constructor*/
    public Division(int divisionId, String division, int countryId) {
        this.countryId = countryId;
        this.division = division;
        this.divisionId = divisionId;
    }

    /**Returns division id*/
    public int getDivisionId() {
        return divisionId;
    }

    /**Returns country id*/
    public int getCountryId() {
        return countryId;
    }

    /**Returns division name*/
    public String getDivision() {
        return division;
    }


    /**Sets division id*/
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    /**Sets country id*/
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }

    /**Sets division name*/
    public void setDivision(String division) {
        this.division = division;
    }

}
