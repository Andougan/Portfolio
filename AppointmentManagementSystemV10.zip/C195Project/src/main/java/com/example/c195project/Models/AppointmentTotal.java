package com.example.c195project.Models;

/**This class defines an object class for the AppointmentTotal objects*/
public class AppointmentTotal {

    /**The Month of appointments*/
    private String month;

    /**The type of appointments*/
    private String type;

    /**The total number of appointments in a particular month with a specific appointment type*/
    private int count;

    /**AppointmentTotal constructor*/
    public AppointmentTotal(String month, String type, int count) {
        this.month = month;
        this.type = type;
        this.count = count;
    }

    /**Returns month*/
    public String getMonth() {
        return month;
    }

    /**Returns type*/
    public String getType() {
        return type;
    }

    /**Returns count*/
    public int getCount() {
        return count;
    }




    /**Sets month*/
    public void setMonth(String month) {
        this.month = month;
    }

    /**Sets type*/
    public void setType(String type) {
        this.type = type;
    }

    /**Sets count*/
    public void setCount(int count) {
        this.count = count;
    }
}
