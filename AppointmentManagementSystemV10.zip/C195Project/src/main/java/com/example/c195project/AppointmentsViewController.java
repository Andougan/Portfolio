package com.example.c195project;

import com.example.c195project.AppointmentUpdateController;
import com.example.c195project.Models.Appointment;
import com.example.c195project.Queries.QueryAppointment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

/**This class controls the appointments view scene*/
public class AppointmentsViewController implements Initializable {

    /**The Appointments table view*/
    public TableView<Appointment> appointmentsTable;

    /**Appointment ID column*/
    public TableColumn appointmentIdCol;

    /**Title column*/
    public TableColumn appointmentTitleCol;

    /**Description column*/
    public TableColumn appointmentDescriptionCol;

    /**Location column*/
    public TableColumn appointmentLocationCol;

    /**Contact column*/
    public TableColumn appointmentContactCol;

    /**Type column*/
    public TableColumn appointmentTypeCol;

    /**Start date and time column*/
    public TableColumn appointmentStartCol;

    /**End date and time column*/
    public TableColumn appointmentEndCol;

    /**Customer ID column*/
    public TableColumn appointmentCustomerIdCol;

    /**User ID column*/
    public TableColumn appointmentUserIdCol;


    /**Week Radio Button: Displays appointments from today through the next seven days in the Appointments table*/
    public RadioButton weekRadioButton;

    /**Month Radio Button: Displays appointments from today through the next 30 days in the Appointments table*/
    public RadioButton monthRadioButton;

    /**All Days Button: Displays all appointments*/
    public RadioButton allDaysButton;


    /**Navigates to the home scene*/
    public void onHome(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("homeScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the customer view scene*/
    public void onCustomers(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("customerViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 700, 400));
        stage.show();
    }

    /**Navigates to the appointment view scene*/
    public void onAppointments(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("appointmentViewScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1030, 400));
        stage.show();
    }



    Alert alert = new Alert(Alert.AlertType.WARNING);

    /**Navigates to the add appointment scene*/
    public void onAddAppointment(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("addAppointmentScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 500, 550));
        stage.show();
    }

    /**Deletes the appointment selected in the appointment table from the database*/
    public void onDeleteAppointment(ActionEvent actionEvent) throws SQLException {

        if (!appointmentsTable.getSelectionModel().isEmpty()) {

            Appointment appointment = appointmentsTable.getSelectionModel().getSelectedItem();

            Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION, "The selected appointment with Appointment ID equal to " + appointment.getAppointmentId() + " and Type " + appointment.getType() + " will be deleted! Are you sure you want to delete this appointment?");
            Alert alertInfo = new Alert(Alert.AlertType.INFORMATION, "The selected appointment with Appointment ID equal to " + appointment.getAppointmentId() + " and Type " + appointment.getType() + " has been deleted.");

            Optional<ButtonType> result = confirmAlert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                QueryAppointment.deleteAppointment(appointment.getAppointmentId());
                QueryAppointment.getAllAppointments().remove(appointment);
                appointmentsTable.setItems(QueryAppointment.getAllAppointments());

                alertInfo.show();

            }
        } else {
            alert.setContentText("Could not delete. Appointment not selected!");
            alert.show();
        }

    }

    /**Passes the selected appointment data to the update appointment scene and then navigates to it*/
    public void onUpdateAppointment(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader();

            loader.setLocation(getClass().getResource("updateAppointmentScene.fxml"));
            Parent parent = loader.load();

            AppointmentUpdateController updateAppointmentController = loader.getController();
            updateAppointmentController.setAppointmentData(appointmentsTable.getSelectionModel().getSelectedItem());

            Scene scene = new Scene(parent, 500, 550);

            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

        } catch (NullPointerException | IOException e) {
            alert.setContentText("Could not update. Appointment not selected!");
            alert.showAndWait();
        }
    }



    /**Populates the appointments table, prepares its columns for population, and sets the actions for the radio buttons using LAMBDA expressions;
     * instead of creating onAction methods, I decided to use three LAMBDA expressions for each of the radio buttons within the initialize method to make
     * the code more efficient and able to run with only one for loop.*/

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            appointmentsTable.setItems(QueryAppointment.getAllAppointments());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        LocalDate now = LocalDate.now();
        LocalDate nowPlusSeven = now.plusDays(7);
        LocalDate nowPlus30 = now.plusDays(30);

        ObservableList<Appointment> weekAppointments = FXCollections.observableArrayList();
        ObservableList<Appointment> monthAppointments = FXCollections.observableArrayList();

        try {
            for (Appointment a : QueryAppointment.getAllAppointments()) {

                LocalDate start = a.getStart().toLocalDateTime().toLocalDate();

                if (!(start.isAfter(nowPlusSeven) || start.isBefore(now))) {
                    weekAppointments.add(a);
                }

                if (!(start.isAfter(nowPlus30) || start.isBefore(now))) {
                    monthAppointments.add(a);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException();
        }


        weekRadioButton.setOnAction(actionEvent -> { appointmentsTable.setItems(weekAppointments); });

        monthRadioButton.setOnAction(actionEvent -> { appointmentsTable.setItems(monthAppointments); });

        allDaysButton.setOnAction(actionEvent -> {
            try {
                appointmentsTable.setItems(QueryAppointment.getAllAppointments());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });


        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        appointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        appointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        appointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        appointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        appointmentStartCol.setCellValueFactory(new PropertyValueFactory<>("start"));
        appointmentEndCol.setCellValueFactory(new PropertyValueFactory<>("end"));
        appointmentCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        appointmentUserIdCol.setCellValueFactory(new PropertyValueFactory<>("userId"));
        appointmentContactCol.setCellValueFactory(new PropertyValueFactory<>("contact"));


    }

}
