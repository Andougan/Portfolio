package com.example.c195project;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**This class launches the application*/
public class Main extends Application {

    /**Displays the login scene*/
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("loginScene.fxml"));
        primaryStage.setScene(new Scene(root, 450, 350));
        primaryStage.show();
    }

    /**Resource bundle containing the key value pairs of words for translating English to French*/
    public static ResourceBundle rb;

    /**Acquires a resource bundle if the default language is French, connects the application to the database, and then launches the application*/
    public static void main(String[] args) throws SQLException {

        try {
            rb = ResourceBundle.getBundle("com/example/c195project/Nat", Locale.getDefault());
            System.out.println(rb.getString("Hello"));
        } catch(MissingResourceException e) {
            System.out.println("Hello");
        }

        JDBC.makeConnection();
        launch(args);
    }
}
