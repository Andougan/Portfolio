package com.example.c195project.Models;

/**This class defines an object class for countries*/
public class Country {

    /**The Country ID of a country*/
    private int countryId;

    /**The Name of a Country*/
    private String countryName;

    /**Country constructor*/
    public Country(int countryId, String countryName) {
        this.countryId = countryId;
        this.countryName = countryName;
    }

    /**Returns country id*/
    public int getCountryId() {
        return countryId;
    }

    /**Returns country name*/
    public String getCountryName() {
        return countryName;
    }



    /**Sets country id*/
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    /**Sets country id*/
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

}
