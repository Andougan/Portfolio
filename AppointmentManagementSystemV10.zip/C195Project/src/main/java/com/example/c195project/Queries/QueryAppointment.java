package com.example.c195project.Queries;

import com.example.c195project.JDBC;
import com.example.c195project.Models.Appointment;
import com.example.c195project.Models.AppointmentTotal;
import com.example.c195project.Models.ContactAppointment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

/**This class contains methods that query the appointments table from the client_schedule database*/
public class QueryAppointment {

    private static ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

    /**Inserts a new appointment into the database*/
    public static void insertAppointment(String title, String description, String location, String type, Timestamp start, Timestamp end, int customerId, int userId, int contactId) throws SQLException {

        String sql = "INSERT INTO appointments (Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) VALUES (?, ?, ?, ?, ?, ?, NOW(), 'Script', NOW(), 'Script', ?, ?, ?)";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, title);
        ps.setString(2, description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setTimestamp(5, start);
        ps.setTimestamp(6, end);
        ps.setInt(7, customerId);
        ps.setInt(8, userId);
        ps.setInt(9, contactId);

        System.out.println("Rows inserted: " + ps.executeUpdate());
    }

    /**Updates an appointment at a specific appointment id*/
    public static void updateAppointment(int appointmentId, String title, String description, String location, String type, Timestamp start, Timestamp end, int customerId, int userId, int contactId) throws SQLException {
        String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setString(1, title);
        ps.setString(2, description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setTimestamp(5, start);
        ps.setTimestamp(6, end);
        ps.setInt(7, customerId);
        ps.setInt(8, userId);
        ps.setInt(9, contactId);
        ps.setInt(10, appointmentId);

        System.out.println("Rows updated: " + ps.executeUpdate());
    }

    /**Deletes an appointment with a specific appointment id*/
    public static void deleteAppointment(int appointmentId) throws SQLException {

        String sql = "DELETE FROM appointments WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, appointmentId);

        System.out.println("Rows deleted: " + ps.executeUpdate());

    }




    /**Deletes appointments with the same customer id*/
    public static void deleteAppointmentByCustomerId(int customerId) throws SQLException {
        String sql = "DELETE FROM appointments WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, customerId);

        System.out.println("Rows deleted: " + ps.executeUpdate());
    }


    /**Returns an observable list of contact appointments with the same contact id*/
    public static ObservableList<ContactAppointment> selectAppointmentsByContactID(int contactId) throws SQLException {

        ObservableList<ContactAppointment> allAppointments = FXCollections.observableArrayList();

        String sql = "SELECT Appointment_ID, Title, Type, Description, Start, end, Customer_ID FROM client_schedule.appointments WHERE Contact_ID  = ? ORDER BY Start";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ps.setInt(1, contactId);

        ResultSet rs = ps.executeQuery();

        while(rs.next()) {

            ContactAppointment appointment = new ContactAppointment(rs.getInt("Appointment_ID"), rs.getString("Title"),
                    rs.getString("Description"), rs.getString("Type"),
                    rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getInt("Customer_ID"));

            allAppointments.add(appointment);

        }

        return allAppointments;
    }

    /**Returns an observable list of contact appointments with the same contact id*/
    public static ObservableList<AppointmentTotal> selectGroupByTypeMonthCount() throws SQLException {

        ObservableList<AppointmentTotal> allGroupBy = FXCollections.observableArrayList();

        String sql = "SELECT monthname(Start), Type, COUNT(Appointment_ID) FROM appointments GROUP BY Type, monthname(Start)";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while(rs.next()) {

            AppointmentTotal total = new AppointmentTotal(rs.getString("monthname(Start)"), rs.getString("Type"), rs.getInt("COUNT(Appointment_ID)"));
            allGroupBy.add(total);

        }

        return allGroupBy;
    }


    /**Adds all the appointments from the database to an observable list*/
    public static void selectAllAppointments() throws SQLException {

        allAppointments.clear();

        String sql = "SELECT * FROM appointments";

        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while(rs.next()) {

            Appointment appointments = new Appointment(rs.getInt("Appointment_ID"), rs.getString("Title"),
                    rs.getString("Description"), rs.getString("Location"), rs.getString("Type"),
                    rs.getTimestamp("Start"), rs.getTimestamp("End"), rs.getInt("Customer_ID"),
                    rs.getInt("User_ID"), QueryContact.selectContactName(rs.getInt("Contact_ID")));

            allAppointments.add(appointments);
        }
    }

    /**Returns an observable list of all appointments from the database*/
    public static ObservableList<Appointment> getAllAppointments() throws SQLException {
        selectAllAppointments();
        return allAppointments;
    }

}
