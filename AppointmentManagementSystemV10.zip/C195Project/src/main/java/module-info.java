module com.example.c195project {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.c195project to javafx.fxml;
    exports com.example.c195project;
    exports com.example.c195project.Models;
    opens com.example.c195project.Models to javafx.fxml;
    exports com.example.c195project.Queries;
    opens com.example.c195project.Queries to javafx.fxml;
}