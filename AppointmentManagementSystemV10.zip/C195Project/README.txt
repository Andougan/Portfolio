
    Title: Appointment Management System


    Application's purpose:
	    The purpose of this application is to give the user the ability to access a database of customers and appointments
	    that they can add to, update, or delete from. The application also outputs a file called login_activity.txt
	    that gives a list of login attempts. It also provides reports that display helpful information gathered from the database.


    Description of the additional report:
        The total number of customers living in a specific country.


	Author ----------------------------------------- Andrew Morgan
	Contact information ---------------------------- amo1895@wgu.edu
	Version ---------------------------------------- 10
	Date ------------------------------------------- 8/7/2023

	IDE -------------------------------------------- IntelliJ IDEA Community Edition 2021.1
	full JDK of version used ----------------------- Java SE 17.0.1,
	JavaFX version compatible with JDK version ----- JavaFX-SDK-17.0.1

    The MySQL Connector driver version number ------ mysql-connector-java-8.0.25


    Directions for how to run the program:

   	    1.After launching the application you will see a basic login screen. Input "test" into both the username and password fields
   	    and click the "Submit" button or press "Enter" on your keyboard. This will take you to the "Home" scene.

		    REPORTS:
		    1.To view the total number of appointments in a particular month with a specific appointment type, click the "Appointments Report" button. You will then see a
		    table view with this information.

		    2.To view all the appointments associated with a specific contact, click the "Contact Schedule Report" button. You will then see an empty table view.
		    You can populate this table by selecting a contact from the combo box above the upper-right corner of the table view.

		    3.To view the total number of customers living in a specific country click the "Customer Residency Report" button. You will then see a table with this information.

	    2.To view customers click on the "Customers" button. You will then be taken to the "Customers" scene which displays a table view with all the customers in the database.

		    1.To create a new customer click on the "Add" button within the "Customers" scene. You will then see a form. Fill it out with all the proper information and click
		    "Save" or "Cancel" which will take you back to the "Customers" Scene.

	        2.To delete a customer select the customer you wish to remove from the table in the "Customers" scene and click "Delete". After that, click "Ok" through the dialogue boxes unless
	        you wish to cancel the deletion.

	        3.To update a customer select the customer you want to modify from the table in the "Customers" scene and click "Update". You will then see a form with all the fields pre-populated
	        with information. Change whatever you want to and then click "Save" or "Cancel" which will redirect you back to the "Customers" scene.

	    3.To view appointments click on the "Appointments" button. You will then see a table view with all the appointments in the database.

		    1.To create a new appointment click on the "Add" button within the "Appointments" scene. You will then see a form. Fill it out with all the proper information and click
		    "Save" or "Cancel" which will take you back to the "Appointments" Scene.

	        2.To delete an appointment select the customer you wish to remove from the table in the "Appointments" scene and click "Delete". After that, click "Ok" through the dialogue boxes
	        unless you wish to cancel the deletion.

	        3.To update an appointment select the appointment you want to modify from the table in the "Appointments" scene and click "Update". You will then see a form with all the fields
		    pre-populated with information. Change whatever you want to and then click "Save" or "Cancel" which will redirect you back to the "Appointments" scene.

