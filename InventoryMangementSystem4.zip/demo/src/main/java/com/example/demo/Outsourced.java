package com.example.demo;

/**This class creates a subclass from the Part class that extends the Company Name as a parameter*/
public class Outsourced extends Part {

    private String compName;

    /**The constructor for the Outsourced subclass*/
    public Outsourced(int id, String name, double price, int stock, int min, int max, String compName) {
        super(id, name, price, stock, min, max);
        this.compName = compName;
    }

    /**Returns the Company Name.
     *@return the Company Name*/
    public String getCompName() {
        return compName;
    }

    /**Sets the Company Name.
     *@param compName the Company Name to set*/
    public void setCompName(String compName) {
        this.compName = compName;
    }
}
