package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;

import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**This class controls the scene that modifies a part in the part table in the main scene*/
public class ModifyPartController {
    public TextField idField;
    public TextField nameField;
    public TextField invField;
    public TextField priceField;
    public TextField minField;
    public TextField maxField;
    public TextField machIdCompNameField;
    public Label machIdCompNameLabel;
    public RadioButton inHouseRadioButton;
    public RadioButton outsourcedRadioButton;

    private static int partIndex;

    /**Sets the Machine ID/Company Name field to "Machine ID"*/
    public void onInHouseRadioButton() {
        machIdCompNameLabel.setText("Machine ID");
    }

    /**Sets the Machine ID/Company Name field to "Company Name"*/
    public void onOutsourcedRadioButton() {
        machIdCompNameLabel.setText("Company Name");
    }

    /**Takes the data from all the fields, puts it into a new part object, and updates the part that was selected in the main scene to the new part at the old part's index*/
    public void onSaveButton(ActionEvent actionEvent) throws IOException {

        Alert alert = new Alert(Alert.AlertType.WARNING);

        try {
            String name = nameField.getText();
            double price = Double.parseDouble(priceField.getText());
            int stock = Integer.parseInt(invField.getText());
            int min = Integer.parseInt(minField.getText());
            int max = Integer.parseInt(maxField.getText());
            String compName = machIdCompNameField.getText();


            if (!name.isEmpty() && !compName.isEmpty()) {
                if(min <= max) {
                    if(min <= stock && stock <= max) {
                        if (inHouseRadioButton.isSelected()) {
                            InHouse part = new InHouse((partIndex + 1), name, price, stock, min, max, Integer.parseInt(machIdCompNameField.getText()));
                            Inventory.updatePart(partIndex, part);
                        } else {
                            Outsourced part = new Outsourced((partIndex + 1), name, price, stock, min, max, compName);
                            Inventory.updatePart(partIndex, part);
                        }

                        Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
                        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                        stage.setScene(new Scene(root, 1065, 500));
                        stage.show();

                    } else {
                        alert.setContentText("Inv needs to be between Min and Max!");
                        alert.showAndWait();
                    }
                } else {
                    alert.setContentText("Min is not less than Max!");
                    alert.showAndWait();
                }
            } else {
                alert.setContentText("The Name and/or Company Name fields cannot be empty!");
                alert.showAndWait();
            }
        }
        catch (NumberFormatException e) {
            alert.setContentText("Number Format Error: The Inv, Price/Cost, Max, Min, and Machine ID fields can only have numeric values! They cannot be empty either!");
            alert.showAndWait();
        }
    }

    /**Navigates to the main scene without saving*/
    public void onCancelButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1065, 500));
        stage.show();

    }

    /**Passes the part selected and its part-table index from the main scene to populate the fields with its values*/
    public void setPartData(Part selectedPart, int selectedIndex) {
        idField.setEditable(false);
        partIndex = selectedIndex;

        idField.setPromptText(String.valueOf(selectedPart.getId()));
        nameField.setText(selectedPart.getName());
        invField.setText(String.valueOf(selectedPart.getStock()));
        priceField.setText(String.valueOf(selectedPart.getPrice()));
        minField.setText(String.valueOf(selectedPart.getMin()));
        maxField.setText(String.valueOf(selectedPart.getMax()));

        if (selectedPart instanceof Outsourced) {
            outsourcedRadioButton.setSelected(true);
            machIdCompNameLabel.setText("Company Name");
            machIdCompNameField.setText(((Outsourced) selectedPart).getCompName());
        } else {
            inHouseRadioButton.setSelected(true);
            machIdCompNameLabel.setText("Machine ID");
            machIdCompNameField.setText(String.valueOf(((InHouse) selectedPart).getMachId()));
        }
    }
}
