package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**This class stores the values from the product and part tables from the main scene in observable lists*/
public class Inventory {

    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();


    /**Adds a part to the allParts observable list*/
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    /**Returns a part in the allParts observable list with an ID that is equal to the parameter*/
    public static Part lookupPart(int partId) {
        for (Part i : Inventory.getAllParts()) {
            if (i.getId() == partId) {
                return i;
            }
        }
        return null;
    }

    /**Returns all the parts in the allParts observable list with names that contain the parameter*/
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        for (Part i : allParts) {
            if (i.getName().contains(partName)) {
                namedParts.add(i);
            }
        }
        return namedParts;
    }

    /**Sets the part from the allParts observable list that is at the index parameter to the selectedPart parameter*/
    public static void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);
    }

    /**Deletes the part from the allParts observable list that is equal to the selectedPart parameter*/
    public static void deletePart(Part selectedPart) {
        allParts.remove(selectedPart);
    }

    /**Returns all the allParts observable list*/
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }



    /**Adds a product to the allProducts observable list*/
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    /**Returns a product in the allProducts observable list with an ID that is equal to the parameter*/
    public static Product lookupProduct(int productId) {
        for (int i = 0; i < allProducts.size(); i++) {

            Product bp = allProducts.get(i);

            if (bp.getId() == productId) {
                return bp;
            }
        }
        return null;

    }

    /**Returns all the products in the allProducts observable list with names that contain the parameter*/
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> namedProducts = FXCollections.observableArrayList();

        for (Product bp : allProducts) {
            if (bp.getName().contains(productName)) {
                namedProducts.add(bp);
            }
        }
        return namedProducts;
    }

    /**Sets the product from the allProducts observable list that is at the index parameter to the selectedProduct parameter*/
    public static void updateProduct(int index, Product newProduct) {
        allProducts.set(index, newProduct);
    }

    /**Deletes the product from the allProducts observable list that is equal to the selectedProduct parameter*/
    public static void deleteProduct(Product selectedProduct) {
        allProducts.remove(selectedProduct);
    }

    /**Returns all the allProducts observable list*/
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

}
