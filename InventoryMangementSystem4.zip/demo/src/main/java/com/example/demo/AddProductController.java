package com.example.demo;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**This class controls the scene that adds a product to the product table in the main scene*/
public class AddProductController implements Initializable {

    public TextField idField;
    public TextField nameField;
    public TextField invField;
    public TextField priceField;
    public TextField minField;
    public TextField maxField;
    public TextField addProductSearchField;

    public TableView<Part> allPartsTable;
    public TableColumn allPartIdCol;
    public TableColumn allPartNameCol;
    public TableColumn allStockCol;
    public TableColumn allPriceCol;

    public TableView<Part> associatedPartsTable;
    public TableColumn associatedPartIdCol;
    public TableColumn associatedPartNameCol;
    public TableColumn associatedStockCol;
    public TableColumn associatedPriceCol;
    private Alert alert = new Alert(Alert.AlertType.WARNING);
    private Product newProduct = new Product(0,"0", 0,0 ,0 ,0 );

    /**Takes the data from all the fields, puts it into a product object, and adds it to the Inventory class*/
    public void onSaveButton(ActionEvent actionEvent) throws IOException {

        int idNum = 0;

        for(int i = 0; i < Inventory.getAllProducts().size(); i++) {
            if(Inventory.getAllProducts().get(i).getId() > idNum) {
                idNum = Inventory.getAllProducts().get(i).getId();
            }
        }

        try {
            idNum++;
            int max = Integer.parseInt(maxField.getText());
            int min = Integer.parseInt(minField.getText());
            String name = nameField.getText();
            int stock = Integer.parseInt(invField.getText());
            double price = Double.parseDouble(priceField.getText());

            double priceSum = 0;

            for(int i = 0; i < newProduct.getAllAssociatedParts().size(); i++) {
                priceSum += newProduct.getAllAssociatedParts().get(i).getPrice();
            }

            if (!name.isEmpty()) {
                if(price >= priceSum) {
                    if (min <= max) {
                        if (min <= stock && stock <= max) {

                            newProduct.setId(idNum);
                            newProduct.setName(name);
                            newProduct.setPrice(price);
                            newProduct.setStock(stock);
                            newProduct.setMin(min);
                            newProduct.setMax(max);

                            Inventory.addProduct(newProduct);


                            Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
                            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                            stage.setScene(new Scene(root, 1065, 500));
                            stage.show();

                        } else {
                            idNum--;
                            alert.setContentText("Inv needs to be between Min and Max!");
                            alert.showAndWait();
                        }
                    } else {
                        idNum--;
                        alert.setContentText("Min needs to be less than Max!");
                        alert.showAndWait();
                    }
                } else {
                    idNum--;
                    alert.setContentText("The sum of associated parts cannot exceed the price!");
                    alert.showAndWait();
                }
            } else {
                idNum--;
                alert.setContentText("The Name field cannot be empty!");
                alert.showAndWait();
            }
        }
        catch (NumberFormatException e) {
            alert.setContentText("Number Format Error: The Inv, Price/Cost, Max, and Min fields can only have numeric values! They cannot be empty either!");
            alert.showAndWait();
        }
    }

    /**Navigates to the main scene without saving*/
    public void onCancelButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1065, 500));
        stage.show();

    }

    /**Adds a part that is selected from the parts Inventory table to the associated parts table*/
    public void onAddProductAddButton() {

        if(!allPartsTable.getSelectionModel().isEmpty()) {
            newProduct.addAssociatedPart(allPartsTable.getSelectionModel().getSelectedItem());
            associatedPartsTable.setItems(newProduct.getAllAssociatedParts());
        } else {
            alert.setContentText("Cannot add part. A part needs to be selected!");
            alert.showAndWait();
        }
    }

    /**Removes a part from the associated parts table*/
    public void onRemoveAssociatedPartButton() {
        if (!associatedPartsTable.getSelectionModel().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to remove this part?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                newProduct.deleteAssociatedPart(associatedPartsTable.getSelectionModel().getSelectedItem());
                associatedPartsTable.setItems(newProduct.getAllAssociatedParts());
            }

        } else {
            alert.setContentText("Cannot remove item. An item needs to be selected!");
            alert.showAndWait();
        }
    }

    /**Searches the parts Inventory table by selecting an ID or by filtering names*/
    public void onAddProductSearchField() {
        Alert alertSearch = new Alert(Alert.AlertType.INFORMATION, "No Search Results.");

        try {
            int partSearch = Integer.parseInt(addProductSearchField.getText());
            allPartsTable.getSelectionModel().select(Inventory.lookupPart(partSearch));

            if(Inventory.lookupPart(partSearch) == null) {
                alertSearch.showAndWait();
            }
            addProductSearchField.setText("");
        }

        catch (NumberFormatException e) {
            String partSearch = addProductSearchField.getText();

            ObservableList<Part> partList = Inventory.lookupPart(partSearch);

            allPartsTable.setItems(partList);

            if(Inventory.lookupPart(partSearch).size() == 0) {
                alertSearch.showAndWait();
                addProductSearchField.setText("");
                allPartsTable.setItems(Inventory.getAllParts());
            }
        }
    }

    /**Prepares the columns of both tables for population, populates the parts inventory table, and disables the ID field when the scene is initialized*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idField.setEditable(false);

        allPartsTable.setItems(Inventory.getAllParts());

        allPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        allPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        allPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        allStockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        associatedPartsTable.setItems(null);

        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        associatedStockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

    }
}
