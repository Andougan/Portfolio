package com.example.demo;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**This class controls the main scene*/
public class MainController implements Initializable {

    public TableView<Part> partsTable;
    public TableColumn partIdCol;
    public TableColumn partNameCol;
    public TableColumn partPriceCol;
    public TableColumn partStockCol;

    public TextField searchPartField;
    public TableView<Product> productsTable;
    public TableColumn productIdCol;
    public TableColumn productNameCol;
    public TableColumn productStockCol;
    public TableColumn productPriceCol;
    public TextField searchProductField;

    /**Navigates to the addPartScene*/
    public void onPartAddButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("addPartScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 650, 500));
        stage.show();

    }

    /**Navigates to the modifyPartScene if part is selected*/
    public void onPartModifyButton(ActionEvent actionEvent) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader();

            loader.setLocation(getClass().getResource("modifyPartScene.fxml"));
            Parent parent = loader.load();

            ModifyPartController modifyController = loader.getController();
            modifyController.setPartData(partsTable.getSelectionModel().getSelectedItem(), partsTable.getSelectionModel().getSelectedIndex());

            Scene scene = new Scene(parent, 650, 500);

            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Could not modify. Item not selected!");
            alert.showAndWait();
        }
    }

    /**Deletes a part from the part table if a part is selected*/
    public void onPartDeleteButton() {
        if (!partsTable.getSelectionModel().isEmpty()) {

            Part part = (Part) partsTable.getSelectionModel().getSelectedItem();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this part?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                ObservableList<Part> partList = Inventory.lookupPart(searchPartField.getText());
                partList.remove(partsTable.getSelectionModel().getSelectedItem());
                partsTable.setItems(partList);

                Inventory.deletePart(part);

                if (partList.size() == 0) {
                    alert = new Alert(Alert.AlertType.INFORMATION, "No Search Results.");
                    alert.showAndWait();
                    searchPartField.setText("");
                    partsTable.setItems(Inventory.getAllParts());
                }
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Could not delete. Item not selected!");
            alert.showAndWait();
        }
    }

    /**Searches the part table by selecting an ID or by filtering names*/
    public void onPartSearch() {
        Alert alertSearch = new Alert(Alert.AlertType.INFORMATION, "No Search Results.");

            try {
                int partSearch = Integer.parseInt(searchPartField.getText());
                partsTable.getSelectionModel().select(Inventory.lookupPart(partSearch));

                if(Inventory.lookupPart(partSearch) == null) {
                    alertSearch.showAndWait();
                }
                searchPartField.setText("");
            }

            catch (NumberFormatException e) {
                String partSearch = searchPartField.getText();

                ObservableList<Part> partList = Inventory.lookupPart(partSearch);

                partsTable.setItems(partList);

                if(Inventory.lookupPart(partSearch).size() == 0) {
                    alertSearch.showAndWait();
                    searchPartField.setText("");
                    partsTable.setItems(Inventory.getAllParts());
                }
            }
    }


    /**Navigates to the addProductScene*/
    public void onProductAddButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("addProductScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1065, 600));
        stage.show();

    }

    /**Navigates to the modifyProductScene if a product is selected*/
    public void onProductModifyButton(ActionEvent actionEvent) throws IOException {

        try {
            FXMLLoader loader = new FXMLLoader();

            loader.setLocation(getClass().getResource("modifyProductScene.fxml"));
            Parent parent = loader.load();

            ModifyProductController modifyController = loader.getController();
            modifyController.setProductData(productsTable.getSelectionModel().getSelectedItem(), productsTable.getSelectionModel().getSelectedIndex());

            Scene scene = new Scene(parent, 1065, 600);

            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Could not modify. Item not selected!");
            alert.showAndWait();
        }

    }

    /**Deletes a product from the product table if a product is selected*/
    public void onProductDeleteButton() {
        if (!productsTable.getSelectionModel().isEmpty()) {

            Product product = (Product) productsTable.getSelectionModel().getSelectedItem();

            if(product.getAllAssociatedParts().isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this product?");
                Optional<ButtonType> result = alert.showAndWait();

                if (result.isPresent() && result.get() == ButtonType.OK) {

                    ObservableList<Product> partList = Inventory.lookupProduct(searchProductField.getText());
                    partList.remove(productsTable.getSelectionModel().getSelectedItem());
                    productsTable.setItems(partList);

                    Inventory.deleteProduct(product);

                    if (partList.size() == 0) {
                        alert = new Alert(Alert.AlertType.INFORMATION, "No Search Results.");
                        alert.showAndWait();
                        searchProductField.setText("");
                        productsTable.setItems(Inventory.getAllProducts());
                    }
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Could not be deleted. Product has associated parts!");
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Could not delete. Item not selected!");
            alert.showAndWait();
        }
    }

    /**Searches the product table by selecting an ID or by filtering names*/
    public void onProductSearch() {

        Alert alertSearch = new Alert(Alert.AlertType.INFORMATION, "No Search Results.");

        try {
            int productSearch = Integer.parseInt(searchProductField.getText());
            productsTable.getSelectionModel().select(Inventory.lookupProduct(productSearch));

            if(Inventory.lookupProduct(productSearch) == null) {
                alertSearch.showAndWait();
            }
            searchProductField.setText("");
        }

        catch (NumberFormatException e) {
            String productSearch = searchProductField.getText();

            ObservableList<Product> partList = Inventory.lookupProduct(productSearch);

           productsTable.setItems(partList);

            if(Inventory.lookupProduct(productSearch).size() == 0) {
                alertSearch.showAndWait();
                searchProductField.setText("");
                productsTable.setItems(Inventory.getAllProducts());
            }
        }
    }

    /**Prepares the columns of the tables for population and then populates them when the scene is initialized*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        partsTable.setItems(Inventory.getAllParts());

        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        partStockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        productsTable.setItems(Inventory.getAllProducts());

        productIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        productStockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
    }

    /**Terminates the program*/
    public void onExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want exit?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            Platform.exit();
        }
    }
}