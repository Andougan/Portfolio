package com.example.demo;

/**This class creates a subclass from the Part class that extends the Machine ID as a parameter*/
public class InHouse extends Part {

    private int machId;

    /**The constructor for the InHouse subclass*/
    public InHouse(int id, String name, double price, int stock, int min, int max, int machId) {
        super(id, name, price, stock, min, max);
        this.machId = machId;
    }

    /**Returns the Machine ID.
     *@return the machId*/
    public int getMachId() {
        return machId;
    }

    /**Sets the Machine ID.
     *@param machId the Machine ID to set*/
    public void setMachId(int machId) {
        this.machId = machId;
    }
}
