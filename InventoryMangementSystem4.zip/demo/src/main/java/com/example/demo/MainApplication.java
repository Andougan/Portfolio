package com.example.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**This class starts an app for the inventory management system*/
public class MainApplication extends Application {

    /**Displays the main scene when the application begins <b>FUTURE ENHANCEMENT</b>:
     *The next version could have a button that switches the color theme of the GUI from a light mode to a dark mode and vice versa*/
    @Override
    public void start(Stage stage) throws Exception {

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("mainScene.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1065, 500);
        stage.setScene(scene);
        stage.show();

    }

    /**Launches the application. demo\src\main\java\com\example\demo\javadoc*/
    public static void main(String[] args) {
        launch();
    }
}