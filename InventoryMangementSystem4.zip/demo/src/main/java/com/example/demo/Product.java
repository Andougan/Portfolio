package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/** This class defines an object class for products*/
public class Product {
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /**
     * The constructor for the Product class
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**Returns the id.
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**Sets the id.
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**Returns the name.
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**Sets the name.
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**Returns the price.
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**Sets the price.
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**Returns the inventory level.
     * @return the stock
     */
    public int getStock() {
        return stock;
    }

    /**Sets the inventory level.
     * @param stock the stock to set
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**Returns the minimum inventory level.
     * @return the min
     */
    public int getMin() {
        return min;
    }

    /**Sets the minimum inventory level.
     * @param min the min to set
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**Returns the maximum inventory level.
     * @return the max
     */
    public int getMax() {
        return max;
    }

    /**Sets the maximum inventory level.
     * @param max the max to set
     */
    public void setMax(int max) {
        this.max = max;
    }

    /**Adds a new part to the associated parts observable list.
     * @param newPart the part to add
     */
    public void addAssociatedPart(Part newPart) {
        associatedParts.add(newPart);
    }

    /**Deletes a part from the associated parts observable list.
     * @param selectedAssociatedPart the part to delete
     */
    public void deleteAssociatedPart(Part selectedAssociatedPart) {
        associatedParts.remove(selectedAssociatedPart);
   }

    /**Returns the associated parts observable list.
     * @return the associated parts
     */
    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }

}
