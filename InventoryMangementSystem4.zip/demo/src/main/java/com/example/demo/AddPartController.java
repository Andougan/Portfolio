package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**This class controls the scene that adds a part to the part table in the main scene*/
public class AddPartController implements Initializable{

    public TextField idField;
    public TextField nameField;
    public TextField priceField;
    public TextField invField;
    public TextField minField;
    public TextField maxField;
    public TextField machIdCompNameField;
    public Label machIdCompNameLabel;
    public RadioButton inHouseRadioButton;
    public RadioButton outsourcedRadioButton;

    /**Sets the Machine ID/Company Name field to "Machine ID"*/
    public void onInHouseRadioButton() {
        machIdCompNameLabel.setText("Machine ID");
    }

    /**Sets the Machine ID/Company Name field to "Company Name"*/
    public void onOutsourcedRadioButton() {
        machIdCompNameLabel.setText("Company Name");
    }

    /**Takes the data from all the fields, puts it into a subclass of the part class, and adds it to the Inventory class <b>RUNTIME ERROR</b>:
     *A runtime error I came across here occurred whenever I attempted to input a letter where an integer should have been;
     *I fixed this by putting a try block around the code where this would happen and a catch block right afterward that would output a dialogue box if an improper value was inputted into a field*/
    public void onSaveButton (ActionEvent actionEvent) throws IOException {

        int idNum = 0;

        for(int i = 0; i < Inventory.getAllParts().size(); i++) {
            if(Inventory.getAllParts().get(i).getId() > idNum) {
                idNum = Inventory.getAllParts().get(i).getId();
            }
        }

        Alert alert = new Alert(Alert.AlertType.WARNING);

        try {
            idNum++;
            int max = Integer.parseInt(maxField.getText());
            int min = Integer.parseInt(minField.getText());
            String compName = machIdCompNameField.getText();
            String name = nameField.getText();
            int stock = Integer.parseInt(invField.getText());
            double price = Double.parseDouble(priceField.getText());

            if (!compName.isEmpty() && !name.isEmpty()) {
                if(min <= max) {
                    if(min <= stock && stock <= max) {
                        if (inHouseRadioButton.isSelected()) {
                            Inventory.addPart(new InHouse(idNum, name, price, stock, min, max, Integer.parseInt(machIdCompNameField.getText())));
                        } else {
                            Inventory.addPart(new Outsourced(idNum, name, price, stock, min, max, machIdCompNameField.getText()));
                        }

                        Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
                        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                        stage.setScene(new Scene(root, 1065, 500));
                        stage.show();
                    } else {
                        idNum--;
                        alert.setContentText("Inv needs to be between Min and Max!");
                        alert.showAndWait();
                    }
                } else {
                    idNum--;
                    alert.setContentText("Min is not less than Max!");
                    alert.showAndWait();
                }
            } else {
                idNum--;
                alert.setContentText("The Name and/or Company Name fields cannot be empty!");
                alert.showAndWait();
            }
        }
        catch (NumberFormatException e) {
            alert.setContentText("Number Format Error: The Inv, Price/Cost, Max, Min, and Machine ID fields can only have numeric values! They cannot be empty either!");
            alert.showAndWait();
        }
    }

    /**Navigates to the main scene without saving*/
    public void onCancelButton (ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1065, 500));
        stage.show();

    }

    /**Disables the ID field when the scene is initialized*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idField.setEditable(false);
    }
}
