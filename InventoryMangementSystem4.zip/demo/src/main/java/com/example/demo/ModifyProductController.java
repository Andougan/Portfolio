package com.example.demo;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

/**This class controls the scene that modifies a product in the product table in the main scene*/
public class ModifyProductController {
    public TextField idField;
    public TextField nameField;
    public TextField invField;
    public TextField priceField;
    public TextField minField;
    public TextField maxField;
    public TextField addProductSearchField;

    public TableView<Part> allPartsTable;
    public TableColumn allPartIdCol;
    public TableColumn allPartNameCol;
    public TableColumn allStockCol;
    public TableColumn allPriceCol;

    public TableView<Part> associatedPartsTable;
    public TableColumn associatedPartIdCol;
    public TableColumn associatedPartNameCol;
    public TableColumn associatedStockCol;
    public TableColumn associatedPriceCol;


    private Alert alert = new Alert(Alert.AlertType.WARNING);
    private int productIndex;
    private Product retrievedProduct;

    /**Takes the data from all the fields, puts it into a new product object, and updates the product that was selected in the main scene to the new product at the old product's index*/
    public void onSaveButton(ActionEvent actionEvent) throws IOException {

        try {
            int max = Integer.parseInt(maxField.getText());
            int min = Integer.parseInt(minField.getText());
            String name = nameField.getText();
            int stock = Integer.parseInt(invField.getText());
            double price = Double.parseDouble(priceField.getText());

            double priceSum = 0;

            for(int i = 0; i < retrievedProduct.getAllAssociatedParts().size(); i++) {
                priceSum += retrievedProduct.getAllAssociatedParts().get(i).getPrice();
            }

            if (!name.isEmpty()) {
                if(price >= priceSum) {
                    if (min <= max) {
                        if (min <= stock && stock <= max) {

                            retrievedProduct.setId(productIndex + 1);
                            retrievedProduct.setName(nameField.getText());
                            retrievedProduct.setPrice(Double.parseDouble(priceField.getText()));
                            retrievedProduct.setStock(Integer.parseInt(invField.getText()));
                            retrievedProduct.setMin(min);
                            retrievedProduct.setMax(max);

                            Inventory.updateProduct(productIndex, retrievedProduct);

                            Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
                            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                            stage.setScene(new Scene(root, 1065, 500));
                            stage.show();
                        } else {
                            alert.setContentText("Inv needs to be between Min and Max!");
                            alert.showAndWait();
                        }
                    } else {
                        alert.setContentText("Min is not less than Max!");
                        alert.showAndWait();
                    }
                } else {
                    alert.setContentText("The sum of associated parts cannot exceed the price!");
                    alert.showAndWait();
                }
            } else {
                alert.setContentText("The Name field cannot be empty!");
                alert.showAndWait();
            }
        }
        catch (NumberFormatException e) {
            alert.setContentText("Number Format Error: The Inv, Price/Cost, Max, and Min fields can only have numeric values! They cannot be empty either!");
            alert.showAndWait();
        }
    }

    /**Navigates to the main scene without saving*/
    public void onCancelButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("mainScene.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, 1065, 500));
        stage.show();

    }

    /**Adds a part that is selected from the parts inventory table to the associated parts table*/
    public void onModifyProductAddButton() {
        if(!allPartsTable.getSelectionModel().isEmpty()) {

            retrievedProduct.addAssociatedPart(allPartsTable.getSelectionModel().getSelectedItem());
            associatedPartsTable.setItems(retrievedProduct.getAllAssociatedParts());

        } else {
            alert.setContentText("Cannot add item. An item needs to be selected!");
            alert.showAndWait();
        }
    }

    /**Removes a part from the associated parts table*/
    public void onRemoveAssociatedPartButton() {
        if(!associatedPartsTable.getSelectionModel().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to remove this part?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                retrievedProduct.deleteAssociatedPart(associatedPartsTable.getSelectionModel().getSelectedItem());
                associatedPartsTable.setItems(retrievedProduct.getAllAssociatedParts());
            }

        } else {
            alert.setContentText("Cannot remove item. An item needs to be selected!");
            alert.showAndWait();
        }
    }

    /**Searches the parts Inventory table by selecting an ID or by filtering names*/
    public void onModifyProductSearchField() {
        Alert alertSearch = new Alert(Alert.AlertType.INFORMATION, "No Search Results.");

        try {
            int partSearch = Integer.parseInt(addProductSearchField.getText());
            allPartsTable.getSelectionModel().select(Inventory.lookupPart(partSearch));

            if(Inventory.lookupPart(partSearch) == null) {
                alertSearch.showAndWait();
            }
            addProductSearchField.setText("");
        }

        catch (NumberFormatException e) {
            String partSearch = addProductSearchField.getText();

            ObservableList<Part> partList = Inventory.lookupPart(partSearch);

            allPartsTable.setItems(partList);

            if(Inventory.lookupPart(partSearch).size() == 0) {
                alertSearch.showAndWait();
                addProductSearchField.setText("");
                allPartsTable.setItems(Inventory.getAllParts());
            }
        }
    }

    /**Passes the product selected and its product-table index from the main scene to populate the fields with its values*/
    public void setProductData(Product selectedProduct, int selectedIndex) {

        idField.setEditable(false);

        productIndex = selectedIndex;
        retrievedProduct = selectedProduct;

        idField.setPromptText(String.valueOf(selectedProduct.getId()));
        nameField.setText(selectedProduct.getName());
        invField.setText(String.valueOf(selectedProduct.getStock()));
        priceField.setText(String.valueOf(selectedProduct.getPrice()));
        minField.setText(String.valueOf(selectedProduct.getMin()));
        maxField.setText(String.valueOf(selectedProduct.getMax()));

        allPartsTable.setItems(Inventory.getAllParts());

        allPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        allPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        allPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        allStockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        associatedPartsTable.setItems(selectedProduct.getAllAssociatedParts());

        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        associatedStockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

    }

}
